package com.bt.texttovoice.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bt.texttovoice.domain.Company;
import com.bt.texttovoice.domain.Vote;
import com.bt.texttovoice.service.CompanyService;
import com.bt.texttovoice.service.VoteSevice;

@RestController
public class MainRestController {
	
	@Autowired
	public VoteSevice voteSevice;
	
	@Autowired
	private CompanyService companyService;
	
	@GetMapping("/rest/voteList")
	public List<Vote> getVoteLisTRest(){
		
		System.out.println("inside Rest ======================");
		return voteSevice.getVoteList();
	}
	
	
	@GetMapping("/rest/company/bt")
	public List<Company> companyDetailsRestBt(){
		
		System.out.println("inside Rest ======================companyService");
		return companyService.getListOfCompanyBt();
	}
	
	@GetMapping("/rest/company/OR")
	public List<Company> companyDetailsRestOr(){
		
		System.out.println("inside Rest ======================companyService");
		return companyService.getListOfCompanyOr();
	}
	
	@GetMapping("/rest/company/EE")
	public List<Company> companyDetailsRestEE(){
		
		System.out.println("inside Rest ======================companyService");
		return companyService.getListOfCompanyEE();
	}
	
	@GetMapping("/rest/company/VF")
	public List<Company> companyDetailsRestVF(){
		
		System.out.println("inside Rest ======================companyService");
		return companyService.getListOfCompanyVf();
	}

}
