package com.bt.texttovoice.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.bt.texttovoice.domain.Company;

@Service
public class CompanyService {
	
	
	public List<Company> getListOfCompany(){
		List<Company> list = new ArrayList<>();
		
		list = Arrays.asList(
					new Company("BT", 6000, 5000, 1000, "MARCH"),
					new Company("OpenReach", 10000, 4000, 6000, "MARCH")
					//new Company("EE", 3000, 5000, -2000, "MARCH"),
					//new Company("Vodafone", 4000, 2000, 2000, "MARCH")
				);
		
		return list;
		
	}
	
	public List<Company> getListOfCompanyBt(){
		List<Company> list = new ArrayList<>();
		
		list = Arrays.asList(
					new Company("BT", 6000, 5000, 1000, "JANUARY"),
					new Company("BT", 10000, 4000, 6000, "FEBRUARY")
					//new Company("BT", 3000, 5000, -2000, "MARCH"),
					//new Company("BT", 4000, 2000, 2000, "APRIL")
				);
		
		return list;
		
	}
	
	public List<Company> getListOfCompanyOr(){
		List<Company> list = new ArrayList<>();
		
		list = Arrays.asList(
					new Company("OpenReach", 30000, 10800, 19200, "JANUARY"),
					new Company("OpenReach", 10000, 11000, -1000, "FEBRUARY")/*,
					new Company("OpenReach", 3500, 5000, -1500, "MARCH"),
					new Company("OpenReach", 52000, 2000, 50000, "APRIL")*/
				);
		
		return list;
		
	}
	
	public List<Company> getListOfCompanyEE(){
		List<Company> list = new ArrayList<>();
		
		list = Arrays.asList(
					new Company("EE", 7000, 5000, 2000, "JANUARY"),
					new Company("EE", 10500, 4000, 6500, "FEBRUARY")/*,
					new Company("EE", 3000, 6000, -3000, "MARCH"),
					new Company("EE", 4000, 2000, 2000, "APRIL")*/
				);
		
		return list;
		
	}
	
	public List<Company> getListOfCompanyVf(){
		List<Company> list = new ArrayList<>();
		
		list = Arrays.asList(
					new Company("Vodafone", 6000, 9000, -3000, "JANUARY"),
					new Company("Vodafone", 10000, 4000, 6000, "FEBRUARY")/*,
					new Company("Vodafone", 3000, 5000, -2000, "MARCH"),
					new Company("Vodafone", 4000, 2000, 2000, "APRIL")*/
				);
		
		return list;
		
	}

}
