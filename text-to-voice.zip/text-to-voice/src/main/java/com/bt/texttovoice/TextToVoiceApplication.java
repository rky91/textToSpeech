package com.bt.texttovoice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TextToVoiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TextToVoiceApplication.class, args);
	}
}
