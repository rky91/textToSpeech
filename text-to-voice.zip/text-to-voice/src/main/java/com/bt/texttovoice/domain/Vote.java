package com.bt.texttovoice.domain;

public class Vote {
	
	private String partyName;
	private int count;
	public Vote(String partyName, int count) {
		super();
		this.partyName = partyName;
		this.count = count;
	}
	public String getPartyName() {
		return partyName;
	}
	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "Vote [partyName=" + partyName + ", count=" + count + "]";
	}
	

}
